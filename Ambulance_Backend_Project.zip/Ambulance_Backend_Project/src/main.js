import { MongoClient } from "mongodb";
import express from "express";
import cors from "cors";

const app = express();
app.use(cors()); // allowing everyone.

async function addrecord(req, res) {
  const uri = "mongodb://127.0.0.1:27017";
  const client = new MongoClient(uri);

  const db = client.db("mydb");
  const messageColl = db.collection("message");

  let inputDoc = {
    message: req.query.message || "default",
  };
  await messageColl.insertOne(inputDoc);

  await client.close();

  // string response
  // res.send("record added")

  // json response :: preferred
  res.json({ opr: "success" });
}

async function findAllMessage(req, res) {
  const uri = "mongodb://127.0.0.1:27017";
  const client = new MongoClient(uri);

  const db = client.db("mydb");
  const messageColl = db.collection("message");

  let list = await messageColl.find().toArray();

  await client.close();
  res.json(list);
}

function helloPost(req, res) {
  let result = { opr: true };
  res.json(result);
}

// NEW TODO API
async function addTodo(req, res) {
  try {
    const uri = "mongodb://127.0.0.1:27017";
    const client = new MongoClient(uri);

    const db = client.db("project");
    const messageColl = db.collection("todo");

    let inputDoc = {
      task: req.query.task,
      description: req.query.description,
    };
    await messageColl.insertOne(inputDoc);

    await client.close();
    res.json({ opr: true });
  } catch (err) {
    res.status(500).send(err.message);
  }
}

async function findAllTodo(req, res) {
  try {
    const uri = "mongodb://127.0.0.1:27017";
    const client = new MongoClient(uri);

    const db = client.db("project");
    const messageColl = db.collection("todo");

    let list = await messageColl.find().toArray();

    await client.close();
    res.json(list);
  } catch (err) {
    res.status(500).send(err.message);
  }
}

async function addUserRecord(req, res) {
  try {
    const uri = "mongodb://127.0.0.1:27017";
    const client = new MongoClient(uri);

    const db = client.db("project");
    const messageColl = db.collection("user");

    let inputDoc = {
      fullname: req.query.fullname,
      username: req.query.username,
      password: req.query.password,
      email: req.query.email,
      number:req.query.number,
      gender:req.query.gender
    };
    await messageColl.insertOne(inputDoc);

    await client.close();

    res.json({ opr: true });
  } catch (err) {
    res.status(500).send(err.message);
  }
}


async function adddriver(req, res) {
  try {
    const uri = "mongodb://127.0.0.1:27017";
    const client = new MongoClient(uri);

    const db = client.db("project");
    const messageColl = db.collection("driver");

    let inputDoc = {
      fullname: req.query.fullname,
      username: req.query.username,
      password: req.query.password,
      email: req.query.email,
      number:req.query.number,
      gender:req.query.gender,
      ambulanceReg : req.query.ambulanceReg,
      licenceNo : req.query.licenceNo
     
    };
    await messageColl.insertOne(inputDoc);

    await client.close();

    res.json({ opr: true });
  } catch (err) {
    res.status(500).send(err.message);
  }
}

async function findAllUser(req, res) {
  try {
    const uri = "mongodb://127.0.0.1:27017";
    const client = new MongoClient(uri);

    const db = client.db("project");
    const messageColl = db.collection("user");

    let list = await messageColl.find().toArray();

    await client.close();
    res.json(list);
  } catch (err) {
    res.status(500).send(err.message);
  }
}

async function addContact(req, res) {
  try {
    const uri = "mongodb://127.0.0.1:27017";
    const client = new MongoClient(uri);

    const db = client.db("project");
    const messageColl = db.collection("contactus");

    let inputDoc = {
      name: req.query.name,
      phone: req.query.phone,
      email: req.query.email,
      message: req.query.message
    };
    await messageColl.insertOne(inputDoc);

    await client.close();
    res.json({ opr: true });
  } catch (err) {
    res.status(500).send(err.message);
  }
}

// LOGIN - AUTHENTICATION
async function loginByGet(req, res) {
  try {
    const uri = "mongodb://127.0.0.1:27017";
    const client = new MongoClient(uri);

    const db = client.db("project");
    const messageColl = db.collection("user");

    let query = { email: req.query.email, password: req.query.password };
    let userRef = await messageColl.findOne(query);

    await client.close();

    // Negative: UserRef CANBE NULL;
    if (!userRef) {
      let errorMessage = `Record Not Found or Authentication Failure: ${req.query.email}`;
      throw new Error(errorMessage);
    }

    // Postive Scenario
    res.json(userRef);
  } catch (err) {
    res.status(500).send(err.message);
  }
}


async function loginByGetdriver(req, res) {
  try {
    const uri = "mongodb://127.0.0.1:27017";
    const client = new MongoClient(uri);

    const db = client.db("project");
    const messageColl = db.collection("driver");

    let query = { email: req.query.email, password: req.query.password };
    let userRef = await messageColl.findOne(query);

    await client.close();

    // Negative: UserRef CANBE NULL;
    if (!userRef) {
      let errorMessage = `Record Not Found or Authentication Failure: ${req.query.email}`;
      throw new Error(errorMessage);
    }

    // Postive Scenario
    res.json(userRef);
  } catch (err) {
    res.status(500).send(err.message);
  }
}


async function findAllAmbulance(req, res) {
  try {
    const uri = "mongodb://127.0.0.1:27017";
    const client = new MongoClient(uri);

    const db = client.db("project");
    const messageColl = db.collection("ambulance");

    let list = await messageColl.find().toArray();

    await client.close();
    res.json(list);
  } catch (err) {
    res.status(500).send(err.message);
  }
}

// http://localhost:4000/addrecord
app.get("/addrecord", addrecord);
app.get("/adddriver", adddriver);
app.get("/findAll", findAllMessage);
app.post("/hello", helloPost);
app.get("/addtodo", addTodo);
app.get("/find-all-todo", findAllTodo);
app.get("/adduser", addUserRecord);
app.get("/find-all-user", findAllUser);
app.get("/contact-us", addContact);

app.get("/login-by-get", loginByGet);
app.get("/loginByGetdriver",loginByGetdriver);
app.get("/findAllAmbulance",findAllAmbulance);

// http://localhost:4000/
app.listen(4000);